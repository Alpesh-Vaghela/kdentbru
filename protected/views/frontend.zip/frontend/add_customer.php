<?php
if (isset($_POST['add_contact_form_submit']))
{
  $email=$_POST['email'];
  $first_name=$_POST['first_name'];
  $last_name=$_POST['last_name'];
  $mobile_pre_code=$_POST['mobile_pre_code'];
  $mobile_number=$_POST['mobile_number'];
  $office_phone_number=$_POST['office_phone_number'];
  $home_phone_number=$_POST['home_phone_number'];
  $address=$_POST['address'];
  $city=$_POST['city'];
  $state=$_POST['state'];
  $zip=$_POST['zip'];
  $visibility_status='active';
  $created_date=date('Y-m-d');
  $ip_address=$_SERVER['REMOTE_ADDR'];
  $customer_profilepic=$_FILES['customer_profilepic'];


  $empt_fields = $fv->emptyfields(array('First Name'=>$first_name,
    'Mobile Number'=>$mobile_number,
    
  ));

  if ($empt_fields)
  {
    $display_msg= '<div class="alert alert-danger text-danger">
    <i class="fa fa-frown-o"></i> <button class="close" data-dismiss="alert" type="button"><i class="fa fa-times-circle-o"></i></button>
    Oops! Following fields are empty<br>'.$empt_fields.'</div>';
  }



  elseif ($customer_profilepic['name']!='')
  {

    $handle= new upload($_FILES['customer_profilepic']);
    $path = SERVER_ROOT.'/uploads/company/'.CURRENT_LOGIN_COMPANY_ID.'/customers/';
    if(!is_dir($path))
    {
      if(!file_exists($path)){
        mkdir($path);
      }
    }


    $newfilename = $handle->file_new_name_body=time();
    $ext=$handle->file_src_name_ext;
    $filename = $newfilename.'.'.$ext;

    if ($handle->image_src_type == 'jpg' || $handle->image_src_type == 'jpeg' || $handle->image_src_type == 'png' )
    {
      if ($handle->uploaded) {
        $handle->Process($path);
        if ($handle->processed)
        {
         $insert=$db->insert("customers",array('company_id'=>CURRENT_LOGIN_COMPANY_ID,
           'email'=>$email,
           'first_name'=>$first_name,
           'last_name'=>$last_name,
           'mobile_number'=>$mobile_number,
           'office_phone_number'=>$office_phone_number,
           'home_phone_number'=>$home_phone_number,
           'address'=>$address,
           'city'=>$city,
           'state'=>$state,
           'zip'=>$zip,
           'visibility_status'=>$visibility_status,
           'created_date'=>$created_date,
           'profile_image'=>$filename,
           'ip_address'=>$ip_address));
   //$db->debug();
         $last_insert_id=$db->insert_id;
         if ($insert){
           $event="<b>Customer</b>  ".ucfirst($first_name)." ".ucfirst($last_name). " was added";
           $db->insert('activity_logs',array('user_id'=>$_SESSION['user_id'],
            'event_type'=>'customer_created',
            'event'=>$event,
            'company_id'=>CURRENT_LOGIN_COMPANY_ID,
            'event_type_id'=>$last_insert_id,
            'created_date'=>date('Y-m-d'),
            'ip_address'=>$_SERVER['REMOTE_ADDR']

          ));
           $display_msg= '<div class="alert alert-success text-success">
           <i class="fa fa-smile-o"></i> <button class="close" data-dismiss="alert" type="button"><i class="fa fa-times-circle-o"></i></button> Contact save successfully.
           </div>';

           echo "<script>
           setTimeout(function(){
             window.location = '".$link->link("customers",user)."'
           },3000);</script>";



         }
       }
     }
   }




   
 }



 else
 {
   
   $insert=$db->insert("customers",array('company_id'=>CURRENT_LOGIN_COMPANY_ID,
     'email'=>$email,
     'first_name'=>$first_name,
     'last_name'=>$last_name,
     'mobile_number'=>$mobile_number,
     'office_phone_number'=>$office_phone_number,
     'home_phone_number'=>$home_phone_number,
     'address'=>$address,
     'city'=>$city,
     'state'=>$state,
     'zip'=>$zip,
     'visibility_status'=>$visibility_status,
     'created_date'=>$created_date,
     'ip_address'=>$ip_address));
   //$db->debug();
   $last_insert_id=$db->insert_id;
   if ($insert){
     $event="<b>Customer</b>  ".ucfirst($first_name)." ".ucfirst($last_name). " was added";
     $db->insert('activity_logs',array('user_id'=>$_SESSION['user_id'],
      'event_type'=>'customer_created',
      'event'=>$event,
      'company_id'=>CURRENT_LOGIN_COMPANY_ID,
      'event_type_id'=>$last_insert_id,
      'created_date'=>date('Y-m-d'),
      'ip_address'=>$_SERVER['REMOTE_ADDR']

    ));
     $display_msg= '<div class="alert alert-success text-success">
     <i class="fa fa-smile-o"></i> <button class="close" data-dismiss="alert" type="button"><i class="fa fa-times-circle-o"></i></button> Contact save successfully.
     </div>';

     echo "<script>
     setTimeout(function(){
       window.location = '".$link->link("customers",user)."'
     },3000);</script>";



   }
 }
}?>

<!--Page content-->
<!--===================================================-->
<div id="page-content">
 <div class="row">
  <div class="col-md-12 "> 
    <?php echo $display_msg;?>
    <div class="panel">
      <div class="panel-heading">
        <div class="panel-control">
          <a href="<?php echo $link->link('customers',user);?>" class="btn btn-default" data-click="panel-expand"><i class="fa fa-users"></i> Pazienti</a>
          
        </div>
        <h3 class="panel-title">Aggiungi Paziente</h3>
      </div>
      <!--Horizontal Form-->
      <!--===================================================-->
      <form id="add_contact_form12" method="post" class="form-horizontal" action="<?php $_SERVER['PHP_SELF'];?>" enctype="multipart/form-data">
        <div class="panel-body">
          <div class="row">
           
            
            <div class="col-md-6"> 
             
             
              <div class="form-group" id="business_name_id">
               <label class="control-label col-md-4">Nome e cognome<font color="red">*</font></label>
               <div class="col-md-8">
                <input class="form-control" placeholder="" type="text" name="first_name" value="<?php echo $_POST['first_name'];?>">
              </div>
            </div>
            <div class="form-group">
             <label class="control-label col-md-4">Email</label>
             <div class="col-md-8">
              <input class="form-control" placeholder="name@address.com" type="text" name="email" value="<?php echo $_POST['email'];?>">
            </div>
          </div>
          <div class="form-group">
           <label class="control-label col-md-4">Tel. Mobile<font color="red">*</font></label>
           
           <div class="col-md-8">
            <input class="form-control" placeholder="" type="text" name="mobile_number" value="<?php echo $_POST['mobile_number'];?>">
          </div>
        </div>
        <div class="form-group">
         <label class="control-label col-md-4">Tel. Ufficio</label>
         <div class="col-md-8">
          <input class="form-control" placeholder="" type="text" name="office_phone_number" value="<?php echo $_POST['office_phone_number'];?>">
        </div>
      </div>
      <div class="form-group">
       <label class="control-label col-md-4">Tel. Casa</label>
       
       <div class="col-md-8">
        <input class="form-control" placeholder="" type="text" name="home_phone_number" value="<?php echo $_POST['home_phone_number'];?>">
      </div>
    </div>
  </div>
  <div class="col-md-6">
    <div class="form-group">
     <label class="control-label col-md-4">Indirizzo</label>
     <div class="col-md-8">
      <textarea class="form-control" rows="5" name="address"><?php echo $_POST['address'];?></textarea>
    </div>
  </div>
  <div class="form-group">
   <label class="control-label col-md-4">Città</label>
   <div class="col-md-8">
    <input class="form-control" placeholder="" type="text" name="city" value="<?php echo $_POST['city'];?>">
  </div>
</div>

<div class="form-group">
 <label class="control-label col-md-4">Cap</label>
 <div class="col-md-8">
  <input class="form-control" placeholder="" type="text" name="zip" value="<?php echo $_POST['zip'];?>">
</div>
</div>
<div class="form-group">
 <label class="control-label col-md-4">Foto</label>
 <div class="col-md-6 file_input" >
  <input type="file" name="customer_profilepic" placeholder="Upload Image" class="form-control">
</div>

</div>


                     <!--     <div class="form-group">
                           <label class="control-label col-md-4">Status</label>
                           <div class="col-md-8">
                              <select class="form-control" name="visibility_status">
                                 <option value="active" <?php if ($_POST['visibility_status']=='active'){echo 'selected';}?>>Active</option>
                                 <option value="inactive" <?php if ($_POST['visibility_status']=='inactive'){echo 'selected';}?>>Inactive</option>
                              </select>
                           </div>
                         </div> -->
                       </div>
                     </div>
                   </div>
                   
                   <div class="panel-footer text-center">
                     
                     <button class="btn btn-info" name="add_contact_form_submit"  id="add_contact_form_submit_id12121" type="submit"> <i class="fa fa-save"></i> Submit</button>  
                   </div>
                   
                 </form>

               </div>
             </div>
             
           </div>
         </div>








